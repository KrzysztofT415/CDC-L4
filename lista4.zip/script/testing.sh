#!/bin/bash
clear

./script/run.sh test/example0.tga
echo -e "\e[34m------------------------------------------------------\e[0m"
./script/run.sh test/example1.tga
echo -e "\e[34m------------------------------------------------------\e[0m"
./script/run.sh test/example2.tga
echo -e "\e[34m------------------------------------------------------\e[0m"
./script/run.sh test/example3.tga