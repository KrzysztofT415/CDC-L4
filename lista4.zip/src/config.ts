export default class CONFIG {
    static IN_FILE_NAME_PROPERTIES = [
        {
            name: 'inputName',
            description: 'Enter input file name',
            type: 'string'
        }
    ]
}
